#ifndef TIME_H
#define TIME_H
#include "sysclk.h"

void timer3_init(void);
void TIMER4_Init (int counts);
#endif