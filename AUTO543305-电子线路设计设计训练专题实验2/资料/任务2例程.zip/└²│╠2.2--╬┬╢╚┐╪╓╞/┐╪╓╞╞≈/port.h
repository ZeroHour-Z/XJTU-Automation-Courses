#ifndef PORT_H
#define PORT_H
#include "sysclk.h"

void Port_IO_Init(void);

#endif