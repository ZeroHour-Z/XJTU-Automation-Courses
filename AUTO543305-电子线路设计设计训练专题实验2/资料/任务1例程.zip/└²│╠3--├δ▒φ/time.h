#ifndef TIME_H
#define TIME_H

extern unsigned int Time_num;

void Timer0_Init(void);
void Timer0_ISR (void);

#endif