#ifndef DIGHT_H
#define DIGHT_H
#define uchar unsigned char

void up_dight(int num);
void meind_dight(int num);
void down_dight(int num);

//���������
uchar code tab[];
#endif