 #include <stdio.h>

#include "c8051f020.h"
#include "lcd.h"
#define SYSCLK    11059200

#define TIMER_PRESCALER            12  // Based on Timer CKCON settings

#define LED_TOGGLE_RATE            100 // LED toggle rate in milliseconds    1ms
                                       // if LED_TOGGLE_RATE = 1, the LED will
                                       // be on for 1 millisecond and off for
                                       // 1 millisecond

// There are SYSCLK/TIMER_PRESCALER timer ticks per second, so
// SYSCLK/TIMER_PRESCALER/1000 timer ticks per millisecond.
#define TIMER_TICKS_PER_MS  SYSCLK/TIMER_PRESCALER/1000

// Note: LED_TOGGLE_RATE*TIMER_TICKS_PER_MS should not exceed 65535 (0xFFFF)
// for the 16-bit timer

#define AUX1     TIMER_TICKS_PER_MS*LED_TOGGLE_RATE
#define AUX2     -AUX1
#define AUX3     AUX2&0x00FF
#define AUX4     ((AUX2&0xFF00)>>8)

#define TIMER0_RELOAD_HIGH       AUX4  // Reload value for Timer0 high byte
#define TIMER0_RELOAD_LOW        AUX3  // Reload value for Timer0 low byte


sbit INT1 = P0^3; //�ɰ����ǽ���0.2�˿�
uchar code str0[]="���ֲ�����";
uchar code str1[]="������Ÿ�1";
uchar code str2[]="�м����Ÿ�2";
uchar code str3[]="�Ҽ�����";
uchar code str4[]="music1";
uchar code str5[]="music2";
#define BEEP P4 //���������
#define do1   261
#define re    294
#define mi    329
#define fa    349
#define so    392
#define la    440
#define si    466
#define do2   523
void Delay_us(unsigned int times)
{
	unsigned int i,j;
	
	for (i = 0; i< times; i++)
	{
		for (j = 0; j < 11; j++)
		{
			_nop_();
    }
  }
}

void Port_IO_Init()
{
	//set P4[1] to push_pull model
    P74OUT |= 0x01;

    //close the alam P4.1
    P4 &= 0xfd;
	
	//uart1,int1
	XBR1 |= 0x14;//�ɰ�����0x10
	XBR2 |= 0x44;
}

void Oscillator_Init()
{
    int i = 0;
    OSCXCN    = 0x67;
    for (i = 0; i < 3000; i++);  // Wait 1ms for initialization
    while ((OSCXCN & 0x80) == 0);
    OSCICN    = 0x08;
}

void Timer0_Init(void)
{
	TH0 = TIMER0_RELOAD_HIGH;           // Reinit Timer0 High register
	TL0 = TIMER0_RELOAD_LOW;
	ET0 = 1;                            // Timer0 interrupt enabled
	TMOD = 0x01;                        // 16-bit Mode Timer0
	//TCON |= 0x10;                        // Timer0 ON
}

void Interrupt_Init()
{
	//INT1
	//low level triggle
	IT1 = 0;
	//enable INT1
	EX1 = 1;
	//enable all interrupt
	EA = 1;
}

void Init_Device(void)
{
    //disable watchdog
    EA = 0;
    WDTCN = 0xde;
    WDTCN = 0xad;
    EA = 1;
	
    Oscillator_Init();
    Port_IO_Init();
	Timer0_Init();
	
	Interrupt_Init();
	
    LcdInit();
}

void delay_beep(unsigned int ms)
{
    unsigned int i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 80; j++);
    }
}



void beep_play( unsigned int freq)
{
      int t=freq/2;
 
 
      while(t>0)            
      {
        BEEP=0XFF;
        Delay_us(23000/freq);    
        t--;
				BEEP=0XFD;
				Delay_us(23000/freq);    
        t--;
      }
      BEEP=0XFD;
      Delay_ms(500);                  
}

void playmusic1()
{
    beep_play(do1);  
    delay_beep(500);       
    beep_play(do1);  
    delay_beep(500);       
    beep_play(so);  
    delay_beep(500);      
    beep_play(so);  
    delay_beep(500);       
		beep_play(la);  
    delay_beep(500);       
    beep_play(la);  
    delay_beep(500);       
    beep_play(so);  
    delay_beep(500);       
    beep_play(fa);  
    delay_beep(500);
    beep_play(fa);  
    delay_beep(500); 
    beep_play(mi);  
    delay_beep(500);
    beep_play(mi);  
    delay_beep(500);
    beep_play(re);  
    delay_beep(500); 
    beep_play(re);  
    delay_beep(500);
    beep_play(do1);  
    delay_beep(500);
} 
	
void playmusic2()
{
    beep_play(do1);  
    delay_beep(500);      
    beep_play(re);  
    delay_beep(500);      
    beep_play(mi);  
    delay_beep(500);       
    beep_play(do1);  
    delay_beep(500);       
		beep_play(do1);  
    delay_beep(500);      
    beep_play(re);  
    delay_beep(500);       
    beep_play(mi);  
    delay_beep(500);       
    beep_play(do1);  
    delay_beep(500);
    beep_play(mi);  
    delay_beep(500); 
    beep_play(fa);  
    delay_beep(500); 
    beep_play(so);  
    delay_beep(500);
    beep_play(mi);  
    delay_beep(500); 
    beep_play(fa);  
    delay_beep(500);
    beep_play(so);  
    delay_beep(500);
} 

//-----------------------------------------------------------------------------
// ������
//-----------------------------------------------------------------------------

void main()
{	
  Init_Device();
	
	INT1 = 1;
	LcdInit();
  WriteStr(0, 0, str0);
	WriteStr(1, 0, str1);
	WriteStr(2, 0, str2);
	WriteStr(3, 0, str3);

    while(1)
    {
			P5 = 0xFB;Delay_us(5);
			P5 = 0xFD;Delay_us(5);
			P5 = 0xFE;Delay_us(5);
			
    }
}

void INT1_ISR(void) interrupt 2
{
	Delay_ms(1);
	switch(P5)
	{
		//sub
			case 0xfb:  //  ���
		   
			LcdInit();
			WriteStr(1, 0, str4);
			playmusic1();
			break;
			
	  	case 0xfd:   //  �м��
		
			LcdInit();
			WriteStr(1, 0, str5);
			playmusic2();
			break;	
		
		  case 0xfe:    //  �Ҽ�
      LcdInit();
			WriteStr(0, 0, str0);
	    WriteStr(1, 0, str1);
	    WriteStr(2, 0, str2);
	    WriteStr(3, 0, str3);
			break;		
	}
}






