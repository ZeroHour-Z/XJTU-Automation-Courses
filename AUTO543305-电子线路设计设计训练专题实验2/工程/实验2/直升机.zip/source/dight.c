#include "SYS_Init.h"
#include "Delay.h"
#include "dight.h"

uchar code tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0x7f};

void up_dight(int num)
{
	int t_num = num/1000;
	int h_num = (num - t_num * 1000)/100;
	int ten_num = (num - t_num*1000 - h_num*100)/10;
	num = num - t_num*1000 - h_num*100 - ten_num*10;

	P5 = 0XF7;
	P6 = 0XFF;
	P7 = tab[num];
	Delay_us(500);

	P5 = 0XFB;
	P6 = 0XFF;
	P7 = tab[ten_num];	      		
	Delay_us(500);

	P5 = 0XFD;
	P6 = 0XFF;
	P7 = tab[h_num];
	Delay_us(500);	

	P5 = 0XFE;
	P6 = 0XFF;
	P7 = tab[t_num];
	Delay_us(500);
}

void meind_dight(int num)
{
	int t_num = num/1000;
	int h_num = (num - t_num * 1000)/100;
  	int ten_num = (num - t_num*1000 - h_num*100)/10;
	num = num - t_num*1000 - h_num*100 - ten_num*10;

	P5 = 0X7F;
	P6 = 0XFF;
	P7 = tab[num];
	Delay_us(500);

	P5 = 0XBF;
	P6 = 0XFF;
	P7 = tab[ten_num];
	Delay_us(500);

	P5 = 0XDF;
	P6 = 0XFF;
	P7 = tab[h_num];
	Delay_us(500);

	P5 = 0XEF;
	P6 = 0XFF;
	P7 = tab[t_num];
	Delay_us(500);
}

void down_dight(int num)
{
	int t_num = num/1000;
	int h_num = (num - t_num * 1000)/100;
  	int ten_num = (num - t_num*1000 - h_num*100)/10;
	num = num - t_num*1000 - h_num*100 - ten_num*10;

	P5 = 0XFF;
	P6 = 0XFE;
	P7 = tab[t_num];
	Delay_us(500);	

	P5 = 0XFF;
	P6 = 0XFD;
	P7 = tab[h_num];
	Delay_us(500);
	
	P5 = 0XFF;
	P6 = 0XFB;
	P7 = tab[ten_num];
	Delay_us(500);
	
	P5 = 0XFF;
	P6 = 0XF7;
	P7 = tab[num];
	Delay_us(500);
}
