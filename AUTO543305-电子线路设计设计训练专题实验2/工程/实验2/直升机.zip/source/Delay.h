#ifndef __DELAY_H
#define __DELAY_H

#include "c8051F020.h"
#include <intrins.h>

void Delay_us(unsigned int val);
void Delay_ms(unsigned int val);
// void Delay_s(unsigned int val);

#endif