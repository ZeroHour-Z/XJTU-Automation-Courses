// 字符编码使用 UTF-8
#include "ADC.h"
#include "DAC.h"
#include "Delay.h"
#include "SYS_Init.h"
#include "Timer.h"
#include "lcd.h"
#include "dight.h"
#include "c8051f020.h"
#include <string.h>
#include <stdio.h>

// 字符串定义
uchar code str0[]="zzh2233712088";
uchar code str1[]="HelicopterSystem";
uchar code str2[]="L:PIDSetting";
uchar code str3[]="R:Start/Stop";

uchar code str_p[]="P:";
uchar code str_i[]="I:";
uchar code str_d[]="D:";

uchar code str_sys[]="System Control";
uchar code str_start[]="L:Start";
uchar code str_stop[]="R:Stop";

// Timers value
unsigned int  timer0_value;
unsigned int  timer1_value;
unsigned int  timer2_value;
unsigned int  timer3_value;
unsigned int  timer4_value;

// ADC & DAC variables
unsigned char channel;   // ADC 通道转换
unsigned int  vref;      // VREF
unsigned int  vtarget;   // VTARGET
unsigned int  vadc;      // ADC 取值
unsigned int  vadc_dec;  // ADC 取值
unsigned int  vdac;      // DAC 输出
unsigned int  vdac_dec;  // DAC 输出

// 菜单状态定义
#define STATE_MENU      0  // 一级菜单状态
#define STATE_PID       1  // PID参数设定二级菜单
#define STATE_SYS       2  // 系统启动停止二级菜单
#define STATE_RUNNING   3  // 系统运行中，显示波形

// 菜单状态变量
unsigned char menu_state = STATE_MENU;

// 控制参数（简化为bang-bang控制）
float pid_p = 0.02;   // P参数（保留用于菜单显示）
float pid_i = 0.001;  // I参数（保留用于菜单显示）
float pid_d = 0.01;   // D参数（保留用于菜单显示）
unsigned char pid_select = 0;  // 当前选中的PID参数：0-P, 1-I, 2-D

// 死区参数（使用bang-bang控制+大死区以保证稳定）
#define DEADZONE 10    // 死区范围：50mV（在目标值±50mV范围内不调整）

// 波形绘制相关变量
unsigned char toshow[64];  // 波形显示缓冲区
unsigned char column = 0;   // 当前列
unsigned char Position = 0; // 当前位置
int placelast = 0;          // 上一个位置
unsigned char waveflag = 0; // 波形标志
unsigned int vvalue = 0;    // 波形值

// 滤波相关变量
unsigned int vadc_filter[4] = {0, 0, 0, 0};  // 滤波缓冲区
unsigned char filter_index = 0;              // 滤波索引

// 按键处理标志
bit key_pressed = 0;
unsigned char key_value = 0;
int press = 0;
int cnt = 0;

// 数码管刷新相关变量
unsigned char digit_pos = 0;  // 当前刷新的数码管位置 (0-11: 上排0-3, 中间4-7, 下排8-11)

void Timer0_Init(void);
void Timer1_Init_Main(void);
void Timer2_Init(void);
void Device_Init(void);
void Do(void);
void Show_Main_Menu(void);
void Show_PID_Menu(void);
void Show_Sys_Menu(void);
void Update_PID_Display(void);
void Draw_Waveform(void);
void Reset_System(void);
void PID_Control(void);

// Timer0初始化，用于数码管刷新
void Timer0_Init(void)
{
	// 设置Timer0为1ms中断一次（用于数码管刷新）
	// 系统时钟11059200Hz，12分频，1ms需要921个计数
	// 65536 - 921 = 64615 = 0xFC67
	TH0 = 0xFC;
	TL0 = 0x67;
	Timer0_Set_Method1;  // 设置定时器 0 为方式 1 定时器功能
	Enable_Timer0;       // 允许 Timer0 溢出中断请求
	Timer0_Start;        // 启动定时器 0
}

// Timer0中断服务程序，用于数码管刷新
void Timer0_ISR(void) interrupt 1
{
	unsigned char digit_value;
	int num_value;
	extern uchar code tab[];  // 声明tab数组
	
	// 重装定时器初值
	TH0 = 0xFC;
	TL0 = 0x67;
	
	// 只在系统运行时显示数码管
	if (menu_state == STATE_RUNNING)
	{
		// 变量声明必须在代码块开头（C51要求）
		unsigned char pos_in_row;
		unsigned char t_num;
		unsigned char h_num;
		unsigned char ten_num;
		unsigned char one_num;
		
		// 根据位置确定要显示的值和位
		if (digit_pos < 4)  // 上排数码管：显示设定值
		{
			num_value = (int)vtarget;
		}
		else if (digit_pos < 8)  // 中间数码管：显示测量值
		{
			num_value = (int)vadc_dec;
		}
		else  // 下排数码管：显示控制电压
		{
			num_value = (int)vdac_dec;
		}
		
		// 计算当前位要显示的数字
		pos_in_row = digit_pos % 4;  // 在当前排中的位置 (0-3)
		t_num = num_value / 1000;
		h_num = (num_value - t_num * 1000) / 100;
		ten_num = (num_value - t_num * 1000 - h_num * 100) / 10;
		one_num = num_value - t_num * 1000 - h_num * 100 - ten_num * 10;
		
		// 先关闭所有位选和段选，避免与按键扫描冲突和显示残影
		P7 = 0XFF;  // 先关闭段选
		P5 = 0XFF;  // 关闭位选
		P6 = 0XFF;
		
		// 根据位置设置P5和P6，并确定要显示的数字
		if (digit_pos < 4)  // 上排（个位->十位->百位->千位）
		{
			if (pos_in_row == 0) { P5 = 0XF7; P6 = 0XFF; digit_value = one_num; }
			else if (pos_in_row == 1) { P5 = 0XFB; P6 = 0XFF; digit_value = ten_num; }
			else if (pos_in_row == 2) { P5 = 0XFD; P6 = 0XFF; digit_value = h_num; }
			else { P5 = 0XFE; P6 = 0XFF; digit_value = t_num; }
		}
		else if (digit_pos < 8)  // 中间（个位->十位->百位->千位）
		{
			if (pos_in_row == 0) { P5 = 0X7F; P6 = 0XFF; digit_value = one_num; }
			else if (pos_in_row == 1) { P5 = 0XBF; P6 = 0XFF; digit_value = ten_num; }
			else if (pos_in_row == 2) { P5 = 0XDF; P6 = 0XFF; digit_value = h_num; }
			else { P5 = 0XEF; P6 = 0XFF; digit_value = t_num; }
		}
		else  // 下排（千位->百位->十位->个位，与上排和中间顺序相反）
		{
			if (pos_in_row == 0) { P5 = 0XFF; P6 = 0XFE; digit_value = t_num; }  // 千位
			else if (pos_in_row == 1) { P5 = 0XFF; P6 = 0XFD; digit_value = h_num; }  // 百位
			else if (pos_in_row == 2) { P5 = 0XFF; P6 = 0XFB; digit_value = ten_num; }  // 十位
			else { P5 = 0XFF; P6 = 0XF7; digit_value = one_num; }  // 个位
		}
		
		// 最后设置段选，确保位选已经稳定
		P7 = tab[digit_value];
		
		// 移动到下一位
		digit_pos++;
		if (digit_pos >= 12) digit_pos = 0;  // 循环刷新12位
	}
}

void Timer1_Init_Main(void)
{
	Enable_Timer1;       // 设定 IE 标志位 1，允许 Timer1 溢出中断请求
	Timer1_Set_Method1;  // 设置定时器 1 为方式 1 定时器功能
}

void Timer1_ISR(void) interrupt 3
{
	timer1_value++;
	TH1 = 0x00; // Reinit Timer1 High register
	TL1 = 0x00;
}

// Timer2初始化，用于波形绘制
void Timer2_Init(void)
{
	RCAP2H = 0x10;
	RCAP2L = 0x00;
	TH2 = 0x10;
	TL2 = 0x00;
	T2CON = 0x04;
	IE |= 0x20;  // 使能Timer2中断
}

// Timer2中断服务程序，用于波形绘制
void Timer2_ISR(void) interrupt 5
{
	int place;
	int dir;
	int i;
	unsigned long int vadc_sum;
	
	if (menu_state == STATE_RUNNING)
	{
		// 读取ADC值
		vadc = ADC_ValueReturn(channel);
		
		// 简单滑动平均滤波（4点平均）
		vadc_filter[filter_index] = vadc;
		filter_index = (filter_index + 1) % 4;
		
		vadc_sum = (unsigned long int)vadc_filter[0] + 
		           (unsigned long int)vadc_filter[1] + 
		           (unsigned long int)vadc_filter[2] + 
		           (unsigned long int)vadc_filter[3];
		vadc = vadc_sum / 4;  // 取平均值
		
		// 转换为电压值
		vadc_dec = (unsigned long int)vadc * (unsigned long int)vref / 4096;
		
		// 计算波形位置 (0-31)
		place = vadc_dec * 31 / vref;
		
		// 限制波形变化速度，避免跳变过大
		if (place > placelast + 3) place = placelast + 3;
		if (place < placelast - 3) place = placelast - 3;
		
		dir = (place > placelast) ? 1 : -1;
		
		// 清屏逻辑：在每个水平位置的开始清除缓冲区
		if (column == 0)
		{
			memset(toshow, 0, sizeof(uchar) * 64);
			// 在屏幕开始位置时清屏
			if (Position == 0)
			{
				ClearAll();
			}
		}
		
		// 绘制波形连线（从上一个点到当前点）
		for(i = placelast; i != place; i += dir)
		{
			if (column < 8)
			{
				toshow[62 - i * 2] |= (0x80 >> column);
			}
			else
			{
				toshow[62 - i * 2 + 1] |= (0x80 >> (column - 8));
			}
			WriteCommand(0x34);
			WriteCommand(0x80 + 31 - i);
			WriteCommand(0x80 + Position);
			WriteCommand(0x30);
			WriteData(toshow[62 - i * 2]);
			WriteData(toshow[62 - i * 2 + 1]);
		}
		
		if (column < 8)
		{
			toshow[62 - place * 2] |= (0x80 >> column);
		}
		else
		{
			toshow[62 - place * 2 + 1] |= (0x80 >> (column - 8));
		}
		
		WriteCommand(0x34);
		WriteCommand(0x80 + 31 - place);
		WriteCommand(0x80 + Position);
		WriteCommand(0x30);
		WriteData(toshow[62 - place * 2]);
		WriteData(toshow[62 - place * 2 + 1]);
		WriteCommand(0x32);
		WriteCommand(0x36);
		
		column++;
		if (column == 16)
		{
			column = 0;
			Position = (Position + 1) % 8;
		}
		placelast = place;
	}
	
	TF2 = 0;
}

void Device_Init(void)
{
	SYS_Init();  // SYS 初始化
	Timer0_Init();  // Timer0初始化用于数码管刷新
	Timer1_Init_Main();
	Timer2_Init();  // Timer2初始化用于波形绘制
	Timer3_Init_ADC0(SYSCLK / SAMPLERATE);  // TIMER3 初始化 
	INT_Init();  // INT 中断初始化
	ADC0_Init();     // ADC0 初始化
	ADC0_Enable(1);  // 使能 ADC0
	DAC0_Init();     // DAC 初始化
	LcdInit();
	Timer0_Start;  // 启动定时器 0
	Timer1_Start;  // 设定 TCON 中断标志位 6，定时器 1 开启
	Timer2_Start;  // 启动Timer2
	timer0_value = 0;
	timer1_value = 0;
	timer2_value = 0;
	timer3_value = 0;
	digit_pos = 0;  // 初始化数码管刷新位置
	channel  = 1;
	vref     = 5244;
	vtarget  = 2800;
	vadc     = 0x0000;
	vadc_dec = 0;
	vdac     = 0x0000;
	vdac_dec = 0;
	memset(toshow, 0, sizeof(toshow));
	// 初始化滤波缓冲区
	memset(vadc_filter, 0, sizeof(vadc_filter));
	filter_index = 0;
}

void PID_Control(void)
{
	int error;
	int delta_output;

	// 误差 = 设定值 - 当前值（当前值 < 设定值时，误差为正，需要增加DAC）
	error = (int)vtarget - (int)vadc_dec;

	// 使用简单的bang-bang控制 + 死区（参考例程）
	if (error > DEADZONE)  // 当前值明显小于目标值
	{
		delta_output = 2;  // 固定增加2（参考例程）
	}
	else if (error < -DEADZONE)  // 当前值明显大于目标值
	{
		delta_output = -2;  // 固定减小2
	}
	else  // 在死区内（-50 < error < 50）
	{
		delta_output = 0;  // 不调整，保持稳定
	}
	
	// 将增量输出加到当前DAC值
	vdac_dec = vdac_dec + delta_output;
	
	// 限幅处理（留一点余量，避免DAC溢出）
	if (vdac_dec < 0) vdac_dec = 0;
	if (vdac_dec > vref - 10) vdac_dec = vref - 10;  // 最大值限制在vref-10，避免计算溢出
	
	// 输出DAC
	vdac = (unsigned long int)vdac_dec * 4096 / (unsigned long int)vref;
	
	// 确保DAC值在有效范围内（0-4095）
	if (vdac > 4095) vdac = 4095;
	
	DAC0_Output(vdac);
}

void Do(void)
{
	// 系统运行时的控制逻辑
	if (menu_state == STATE_RUNNING)
	{
		if ((timer1_value & 0x0007) == 0x0001)
		{     
			if (channel == 1)
			{
				// 从 ADC0 AIN1 取得 10 位 16 进制数 vadc
				vadc = ADC_ValueReturn(channel);
				// 将 vadc 转化为 10 进制数进行计算
				vadc_dec = (unsigned long int)vadc * (unsigned long int)vref / 4096;
				// 使用PID控制算法
				PID_Control();
			}
		}
		// 数码管显示已移至Timer0中断中处理，避免闪烁
	}
}

void Show_Main_Menu(void)
{
	LcdClear();
	WriteStr(0, 0, str0);
	WriteStr(1, 0, str1);
	WriteStr(2, 0, str2);
	WriteStr(3, 0, str3);
}

void Show_PID_Menu(void)
{
	LcdClear();
	pid_select = 0;  // 重置选择
	Update_PID_Display();
}

void Update_PID_Display(void)
{
	char temp_buf[17];
	
	// 清空显示区域
	LineClear(0);
	LineClear(1);
	LineClear(2);
	
	// 显示P参数
	if (pid_select == 0)
	{
		WriteChar(0, 0, '>');
	}
	WriteStr(0, 1, str_p);
	sprintf(temp_buf, "%2.3f", pid_p);
	WriteStr(0, 3, temp_buf);
	
	// 显示I参数
	if (pid_select == 1)
	{
		WriteChar(1, 0, '>');
	}
	WriteStr(1, 1, str_i);
	sprintf(temp_buf, "%2.3f", pid_i);
	WriteStr(1, 3, temp_buf);
	
	// 显示D参数
	if (pid_select == 2)
	{
		WriteChar(2, 0, '>');
	}
	WriteStr(2, 1, str_d);
	sprintf(temp_buf, "%2.3f", pid_d);
	WriteStr(2, 3, temp_buf);
}

void Show_Sys_Menu(void)
{
	LcdClear();
	WriteStr(0, 0, str_sys);
	WriteStr(1, 0, str_start);
	WriteStr(2, 0, str_stop);
}

void Draw_Waveform(void)
{
	int i;
	// 波形绘制在Timer2中断中完成
	// 这里只需要清屏和初始化
	LcdClear();
	ClearAll();
	column = 0;
	Position = 0;
	placelast = 0;
	memset(toshow, 0, sizeof(toshow));
	// 初始化滤波缓冲区
	for (i = 0; i < 4; i++)
	{
		vadc_filter[i] = 0;
	}
	filter_index = 0;
}

void Reset_System(void)
{
	int i;
	// 复位系统到初始状态
	vdac = 0x0000;
	vdac_dec = 0;
	DAC0_Output(0);
	column = 0;
	Position = 0;
	placelast = 0;
	memset(toshow, 0, sizeof(toshow));
	ClearAll();
	// 初始化滤波缓冲区
	for (i = 0; i < 4; i++)
	{
		vadc_filter[i] = 0;
	}
	filter_index = 0;
	// 初始化DAC为设定值的60%，让系统从较低值开始调整
	vdac_dec = (vtarget * 6) / 10;
	if (vdac_dec > vref - 10) vdac_dec = vref - 10;
	vdac = (unsigned long int)vdac_dec * 4096 / (unsigned long int)vref;
	if (vdac > 4095) vdac = 4095;  // 确保DAC值不超过10位最大值
	DAC0_Output(vdac);
}

void INT1_ISR(void) interrupt 2
{
	// 只有在按键未被按下时才处理新的按键
	if(press == 0)
	{
		switch (P5)
		{
			case 0xfb:  // 左键
				press = 1;
				key_value = 1;
				key_pressed = 1;
				break;
			case 0xfd:  // 中键
				press = 1;
				key_value = 2;
				key_pressed = 1;
				break;
			case 0xfe:  // 右键
				press = 1;
				key_value = 3;
				key_pressed = 1;
				break;
			default:
				break;
		}
	}
	
	// 防抖计数器
	if(press == 1)
	{
		cnt++;
		if(cnt >= 30)  // 增加防抖时间
		{
			cnt = 0;
			press = 0;
		}
	}
}

main(void)
{
	Device_Init();
	Device_Init();
	Show_Main_Menu();
	
	while(1)
	{
		Do();
		
		// 按键扫描（系统运行时跳过，避免与上排数码管冲突）
		if (menu_state != STATE_RUNNING)
		{
			P5 = 0xFB; Delay_ms(5);
			P5 = 0xFD; Delay_ms(5);
			P5 = 0xFE; Delay_ms(5);
		}
		
		// 处理按键事件
		if (key_pressed)
		{
			key_pressed = 0;
			
			switch (menu_state)
			{
				case STATE_MENU:  // 一级菜单
					if (key_value == 1)  // 左键：进入PID设定菜单
					{
						menu_state = STATE_PID;
						pid_select = 0;
						Show_PID_Menu();
					}
					else if (key_value == 3)  // 右键：进入系统启动停止菜单
					{
						menu_state = STATE_SYS;
						Show_Sys_Menu();
					}
					break;
					
				case STATE_PID:  // PID参数设定菜单
					if (key_value == 1)  // 左键：减小当前参数
					{
						if (pid_select == 0)
						{
							if (pid_p > 0.1) pid_p -= 0.1;
						}
						else if (pid_select == 1)
						{
							if (pid_i > 0.01) pid_i -= 0.01;
						}
						else if (pid_select == 2)
						{
							if (pid_d > 0.001) pid_d -= 0.001;
						}
						Update_PID_Display();
					}
					else if (key_value == 2)  // 中键：切换参数选择
					{
						if (pid_select < 2)
						{
							pid_select = pid_select + 1;
							Update_PID_Display();
						}
						else if (pid_select == 2)
						{
							pid_select = 0;
							menu_state = STATE_MENU;
							Show_Main_Menu();
						}
					}
					else if (key_value == 3)  // 右键：增加当前参数
					{
						if (pid_select == 0) pid_p += 0.1;
						else if (pid_select == 1) pid_i += 0.01;
						else if (pid_select == 2) pid_d += 0.001;
						Update_PID_Display();
					}
					break;
					
				case STATE_SYS:  // 系统启动停止菜单
					if (key_value == 1)  // 左键：启动系统
					{
						menu_state = STATE_RUNNING;
						Draw_Waveform();
					}
					else if (key_value == 3)  // 右键：停止系统，返回主菜单
					{
						menu_state = STATE_MENU;
						Reset_System();
						Show_Main_Menu();
					}
					break;
					
				case STATE_RUNNING:  // 系统运行中
					if (key_value == 1)  // 左键：减小电压设定值
					{
						if (vtarget > 10) vtarget -= 10;
						Delay_ms(200);  // 添加延时，防止重复触发
					}
					else if (key_value == 2)  // 中键：停止系统，返回主菜单
					{
						menu_state = STATE_MENU;
						Reset_System();
						Show_Main_Menu();
					}
					else if (key_value == 3)  // 右键：增加电压设定值
					{
						if (vtarget < vref - 100) vtarget += 10;
						Delay_ms(200);  // 添加延时，防止重复触发
					}
					break;
			}
			
			key_value = 0;
		}
	}
}
