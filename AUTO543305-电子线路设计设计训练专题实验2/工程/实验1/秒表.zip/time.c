#include "sysclk.h"
#include "time.h"
//11059200
#define TIMER0_RELOAD_HIGH 0xdc// Reload value for Timer0 high byte
#define TIMER0_RELOAD_LOW 0x00   // Reload value for Timer0 low byte
//10ms

void Timer0_Init()
{
	TH0 = TIMER0_RELOAD_HIGH;           // ���ø�8λ
	TL0 = TIMER0_RELOAD_LOW;
	TMOD = 0x01;                        // ����Ϊ16λģʽ
	ET0 = 1;                            // ʹ�ܶ�ʱ��0
}

void Timer0_ISR (void) interrupt 1
{
	TH0 = TIMER0_RELOAD_HIGH;           // Reinit Timer0 High register
	TL0 = TIMER0_RELOAD_LOW;
	P4=0XFD;
	Time_num++;
	if(Time_num >= 6000) Time_num = 0;
	if(Time_num%600 == 0) P4=0XFF;

}