#ifndef PORT_H
#define PORT_H

extern unsigned int Time_num;

void Port_IO_Init(void);
void Interrupt_Init(void);
void INT1_ISR(void);

#endif