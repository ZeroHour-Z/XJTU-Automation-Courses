#include "sysclk.h"
#include <intrins.h>

void SYSCLK_Init (void)
{
   int i;                      
   OSCXCN = 0x67;              // 选择外部振荡器，晶振频率为11.0592MHz
   for (i=0; i<256; i++);      // 等待晶振稳定
   while (!(OSCXCN & 0x80));   // 读取最高位，判断晶振是否稳定
   OSCICN = 0x88;              // 选择外部振荡器为时钟源
}

void Delay_us(unsigned int times)//微秒级延时函数（参考例程4的实现）
{
    unsigned int i, j;

    for (i = 0; i < times; i++)
    {
        for (j = 0; j < 11; j++)
        {
            _nop_();
        }
    }
}

void Delay_ms(unsigned int times)//毫秒级延时函数
{
    unsigned int i, j;
    for (i=0; i<times; i++)
        for (j=0; j<1300; j++);
}

// 蜂鸣器简单鸣叫函数（参考例程3--秒表）
void SimpleBeep(void)
{
    P4 = 0xFF;      // 开启蜂鸣器
    Delay_ms(300);  // 响300ms
    P4 = 0xFD;      // 关闭蜂鸣器
}

