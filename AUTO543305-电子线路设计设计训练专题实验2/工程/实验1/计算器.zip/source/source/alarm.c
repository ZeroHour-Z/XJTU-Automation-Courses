#include "alarm.h"
#include "lcd.h"
#include "digitron.h"
#include "time.h"
#include "key.h"
#include "sysclk.h"
#include "alarm_image.h"
#include "C8051F020.h"
#include <stdio.h>

char xdata alarm_buffer[32];

// 闹钟状态变量
unsigned char alarm_enabled = ALARM_OFF;     // 闹钟是否开启（0=关闭，1=开启）
DateTime alarm_time = {2025, 11, 14, 10, 41, 0};  // 闹钟时间（默认7:00）
unsigned char alarm_ringing = 0;              // 闹钟是否正在响铃（0=否，1=是）

// 闹钟设置状态变量
static unsigned char alarm_setting = 0;       // 是否在设置模式（0=否，1=是）
static unsigned char setting_field = ALARM_SET_HOUR;  // 当前设置的字段

void Alarm_Init(void)
{
    alarm_enabled = ALARM_OFF;
    alarm_ringing = 0;
    alarm_setting = 0;
    setting_field = ALARM_SET_HOUR;
    alarm_time.hour = 7;
    alarm_time.minute = 0;
}

void Alarm_Enable(void)
{
    alarm_enabled = ALARM_ON;
}

void Alarm_Disable(void)
{
    alarm_enabled = ALARM_OFF;
    alarm_ringing = 0;
}

unsigned char Alarm_IsEnabled(void)
{
    return alarm_enabled;
}

unsigned char Alarm_IsRinging(void)
{
    return alarm_ringing;
}

unsigned char Alarm_IsSetting(void)
{
    return alarm_setting;
}

void Alarm_CheckTime(void)
{
    // 检查是否到达闹钟时间（只在闹钟开启且未响铃时检查）
    // 注意：只在秒数为0时检查，避免同一分钟内重复触发
    if (alarm_enabled == ALARM_ON && alarm_ringing == 0 && current_time.second == 0)
    {
        // 比较时和分
        if (current_time.hour == alarm_time.hour && 
            current_time.minute == alarm_time.minute)
        {
            // 到达闹钟时间，开始响铃
            Alarm_StartRinging();
        }
    }
}

void Alarm_StartRinging(void)
{
    alarm_ringing = 1;
    // 蜂鸣器响一声
    SimpleBeep();
    // 显示图片
		LcdInit();
    ImageShow1((unsigned char *)alarm_image1);
}

void Alarm_StopRinging(void)
{
    alarm_ringing = 0;
    // 关闭蜂鸣器（SimpleBeep已经自动关闭）
    P4 = 0xFD;  // 确保蜂鸣器关闭
}

void Alarm_EnterSetting(void)
{
    alarm_setting = 1;
    setting_field = ALARM_SET_HOUR;
    Alarm_SettingDisplay();
}

void Alarm_ExitSetting(void)
{
    alarm_setting = 0;
    setting_field = ALARM_SET_HOUR;
    
    // 如果正在响铃，不刷新显示（保持图片显示）
    if (alarm_ringing == 1)
    {
        return;
    }
    
    // 显示闹钟状态
    LcdClear();
    WriteASCIIStr(0, 0, "Alarm");
    if (alarm_enabled == ALARM_ON)
    {
        sprintf(alarm_buffer, "Time: %02u:%02u", 
                (unsigned int)alarm_time.hour, 
                (unsigned int)alarm_time.minute);
        WriteASCIIStr(1, 0, alarm_buffer);
        WriteASCIIStr(2, 0, "Status: ON");
        WriteASCIIStr(3, 0, "L:Toggle M:Exit");
    }
    else
    {
        sprintf(alarm_buffer, "Time: %02u:%02u", 
                (unsigned int)alarm_time.hour, 
                (unsigned int)alarm_time.minute);
        WriteASCIIStr(1, 0, alarm_buffer);
        WriteASCIIStr(2, 0, "Status: OFF");
        WriteASCIIStr(3, 0, "L:Toggle M:Exit");
    }
    DisplayNumber(alarm_time.hour * 100 + alarm_time.minute);
}

void Alarm_SettingDisplay(void)
{
    // 清空显示
    LineClear(0);
    LineClear(1);
    LineClear(2);
    LineClear(3);
    
    // 显示标题
    WriteASCIIStr(0, 0, "Alarm Setting");
    
    // 根据当前选择的字段显示对应的设置界面
    switch(setting_field)
    {
        case ALARM_SET_HOUR:
            sprintf(alarm_buffer, "Hour: %02u", (unsigned int)alarm_time.hour);
            WriteASCIIStr(1, 0, alarm_buffer);
            WriteASCIIStr(2, 0, "L:Dec R:Inc");
            WriteASCIIStr(3, 0, "M:Next");
            DisplayNumber((int)alarm_time.hour);
            break;
            
        case ALARM_SET_MINUTE:
            sprintf(alarm_buffer, "Minute: %02u", (unsigned int)alarm_time.minute);
            WriteASCIIStr(1, 0, alarm_buffer);
            WriteASCIIStr(2, 0, "L:Dec R:Inc");
            WriteASCIIStr(3, 0, "M:Next");
            DisplayNumber((int)alarm_time.minute);
            break;
            
        case ALARM_SET_EXIT:
            WriteASCIIStr(1, 0, "Exit Setting?");
            WriteASCIIStr(2, 0, "M:Confirm");
            WriteASCIIStr(3, 0, "L/R:Cancel");
            DisplayNumber(9999);
            break;
    }
}

unsigned char Alarm_ProcessKey(unsigned char key)
{
    unsigned char need_return = 0;
    
    // 首先检查是否在设置模式
    if (alarm_setting == 1)
    {
        // 在设置模式下处理按键
        switch(setting_field)
        {
            case ALARM_SET_HOUR:
                switch(key)
                {
                    case 1:  // KEY_LEFT
                        // 左键：减少小时
                        if (alarm_time.hour > 0)
                            alarm_time.hour--;
                        else
                            alarm_time.hour = 23;
                        Alarm_SettingDisplay();
                        break;
                    case 2:  // KEY_MIDDLE
                        // 中键：切换到下一个字段（分）
                        setting_field = ALARM_SET_MINUTE;
                        Alarm_SettingDisplay();
                        break;
                    case 3:  // KEY_RIGHT
                        // 右键：增加小时
                        if (alarm_time.hour < 23)
                            alarm_time.hour++;
                        else
                            alarm_time.hour = 0;
                        Alarm_SettingDisplay();
                        break;
                    default:
                        break;
                }
                break;
                
            case ALARM_SET_MINUTE:
                switch(key)
                {
                    case 1:  // KEY_LEFT
                        // 左键：减少分钟
                        if (alarm_time.minute > 0)
                            alarm_time.minute--;
                        else
                            alarm_time.minute = 59;
                        Alarm_SettingDisplay();
                        break;
                    case 2:  // KEY_MIDDLE
                        // 中键：切换到退出确认
                        setting_field = ALARM_SET_EXIT;
                        Alarm_SettingDisplay();
                        break;
                    case 3:  // KEY_RIGHT
                        // 右键：增加分钟
                        if (alarm_time.minute < 59)
                            alarm_time.minute++;
                        else
                            alarm_time.minute = 0;
                        Alarm_SettingDisplay();
                        break;
                    default:
                        break;
                }
                break;
                
            case ALARM_SET_EXIT:
                switch(key)
                {
                    case 1:  // KEY_LEFT
                    case 3:  // KEY_RIGHT
                        // 取消退出，返回设置分
                        setting_field = ALARM_SET_MINUTE;
                        Alarm_SettingDisplay();
                        break;
                    case 2:  // KEY_MIDDLE
                        // 确认退出设置，自动开启闹钟
                        Alarm_Enable();
                        Alarm_ExitSetting();
                        break;
                    default:
                        break;
                }
                break;
        }
    }
    else
    {
        // 正常模式下的按键处理
        if (key == 3 || key == KEY_RIGHT)  // KEY_RIGHT = 3
        {
            // 右键进入设置模式
            if (alarm_ringing == 1)
            {
                Alarm_StopRinging();
                LcdInit();
                Alarm_ExitSetting();
            }
            else
            {
                // 退出闹钟
                need_return = 1;
            }
        }
        else if (key == 1 || key == KEY_LEFT)  // KEY_LEFT = 1
        {
            // 左键：切换闹钟开关
            if (alarm_enabled == ALARM_ON)
            {
                Alarm_Disable();
            }
            else
            {
                Alarm_Enable();
            }
            Alarm_ExitSetting();  // 刷新显示
        }
        else if (key == 2 || key == KEY_MIDDLE)  // KEY_MIDDLE = 2
        {
            // 中键：如果在响铃状态，停止响铃；否则退出闹钟
            if (alarm_ringing == 1)
            {
                Alarm_StopRinging();
                LcdInit();
                Alarm_ExitSetting();
            }
            else
            {
                // 退出闹钟
                need_return = 1;
            }
        }
    }
    
    return need_return;
}

