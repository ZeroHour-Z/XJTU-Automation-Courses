#include "sysclk.h"
#include "digitron.h"
#include "C8051F020.h"

// 共阴极数码管编码表：0-9
uchar code tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0x7f};

// 在第一行显示4位数字
void up_dight(int num)
{
	int t_num = num/1000;
	int h_num = (num - t_num * 1000)/100;
    int ten_num = (num - t_num*1000 - h_num*100)/10;
	num = num - t_num*1000 - h_num*100 - ten_num*10;
	
	P5 = 0XF7;  // 第一行第一位
	P6 = 0XFF;
	P7 = tab[num];
	Delay_us(500);
	
    P5 = 0XFB;  // 第一行第二位
	P6 = 0XFF;
	P7 = tab[ten_num];
	Delay_us(500);
	
    P5 = 0XFD;  // 第一行第三位
	P6 = 0XFF;
	P7 = tab[h_num];
	Delay_us(500);
	
	P5 = 0XFE;  // 第一行第四位
	P6 = 0XFF;
	P7 = tab[t_num];
	Delay_us(500);
}

// 在第二行显示4位数字
void meind_dight(int num)
{
	int t_num = num/1000;
	int h_num = (num - t_num * 1000)/100;
    int ten_num = (num - t_num*1000 - h_num*100)/10;
	num = num - t_num*1000 - h_num*100 - ten_num*10;
	
	P5 = 0X7F;  // 第二行第一位
	P6 = 0XFF;
	P7 = tab[num];
	Delay_us(500);
	
	P5 = 0XBF;  // 第二行第二位
	P6 = 0XFF;
	P7 = tab[ten_num];
	Delay_us(500);
	
	P5 = 0XDF;  // 第二行第三位
	P6 = 0XFF;
	P7 = tab[h_num];
	Delay_us(500);
	
	P5 = 0XEF;  // 第二行第四位
	P6 = 0XFF;
	P7 = tab[t_num];
	Delay_us(500);
}

// 在第三行显示4位数字
void down_dight(int num)
{
	int t_num = num/1000;
	int h_num = (num - t_num * 1000)/100;
    int ten_num = (num - t_num*1000 - h_num*100)/10;
	num = num - t_num*1000 - h_num*100 - ten_num*10;
	
	P5 = 0XFF;  // 第三行第一位
	P6 = 0XFE;
	P7 = tab[t_num];
	Delay_us(500);
	
	P5 = 0XFF;  // 第三行第二位
	P6 = 0XFD;
	P7 = tab[h_num];
	Delay_us(500);
	
	P5 = 0XFF;  // 第三行第三位
	P6 = 0XFB;
	P7 = tab[ten_num];
	Delay_us(500);
	
	P5 = 0XFF;  // 第三行第四位
	P6 = 0XF7;
	P7 = tab[num];
	Delay_us(500);
}

// 在8位数码管上显示数字（最多8位）
void DisplayNumber8(int num)
{
    if (num < 0) num = 0;
    if (num > 99999999) num = 99999999;
    
    // 分别显示在三个区域
    up_dight(num % 10000);
    meind_dight((num / 10000) % 10000);
    down_dight((num / 100000000) % 10000);
}

// 显示4位数字（在第一行）
void DisplayNumber(int num)
{
    if (num < 0) num = 0;
    if (num > 9999) num = 9999;
    up_dight(num);
}

// 清空数码管显示
void ClearDigitron(void)
{
    P5 = 0xFF;
    P6 = 0xFF;
    P7 = 0xFF;
}

