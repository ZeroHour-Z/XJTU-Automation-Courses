#include "sysclk.h"
#include "port.h"
#include "C8051F020.h"

void Port_IO_Init()
{
   P74OUT |= 0x01;
   XBR2 |= 0x40;
   P4 &= 0xfd;
   XBR1 |= 0x14;
   XBR2 |= 0x44;
}

void Interrupt_Init()
{
   IT1 = 1;       
   EX1 = 1;       
   EA = 1;        
}
