#include "calculator.h"
#include "lcd.h"
#include "digitron.h"
#include "key.h"
#include <stdio.h>
#include <string.h>

// 选择项类型
#define SELECT_TYPE_DIGIT    0  // 数字
#define SELECT_TYPE_OPERATOR 1  // 运算符
#define SELECT_TYPE_EQUAL    2  // 等号

unsigned long xdata num1 = 0;   // 第一个数（限制为0-9）
unsigned long xdata num2 = 0;   // 第二个数（限制为0-9）
unsigned long xdata result = 0; // 结果
unsigned char xdata operator = OP_NONE;
unsigned char xdata state = CALC_STATE_INPUT1;

char xdata calc_buffer[32];  // 用于格式化显示的缓冲区

// 当前选择项（0-9表示数字，10-13表示+-*/，14表示等号）
unsigned char xdata current_selection = 0;  // 0-14：0-9是数字，10=+, 11=-, 12=*, 13=/, 14==

// 获取当前选择项的类型
unsigned char GetSelectionType(void)
{
    if (current_selection < 10)
        return SELECT_TYPE_DIGIT;
    else if (current_selection < 14)
        return SELECT_TYPE_OPERATOR;
    else
        return SELECT_TYPE_EQUAL;
}

// 获取当前选择项对应的运算符
unsigned char GetSelectionOperator(void)
{
    if (current_selection == 10) return OP_ADD;
    if (current_selection == 11) return OP_SUB;
    if (current_selection == 12) return OP_MUL;
    if (current_selection == 13) return OP_DIV;
    return OP_NONE;
}

void Calculator_Init(void)
{
    num1 = 0;
    num2 = 0;
    result = 0;
    operator = OP_NONE;
    state = CALC_STATE_INPUT1;
    current_selection = 0;
    Calculator_Display();
}

unsigned char Calculator_ProcessKey(unsigned char key)
{
    // 按键分配：
    // 中键（KEY_MIDDLE）：退出功能
    // 右键（KEY_RIGHT）：循环选择0-9和运算符
    // 左键（KEY_LEFT）：确认选择
    
    if (key == KEY_MIDDLE)
    {
        // 中键：退出到菜单
        return 1;
    }
    else if (key == KEY_RIGHT)
    {
        // 右键：循环选择（0,1,2,3,4,5,6,7,8,9,+, -, *, /, =）
        current_selection = (current_selection + 1) % 15;
    }
    else if (key == KEY_LEFT)
    {
        // 左键：确认选择
        unsigned char sel_type = GetSelectionType();
        
        if (sel_type == SELECT_TYPE_DIGIT)
        {
            // 选择的是数字（0-9）
            unsigned char digit = current_selection;
            
            if (state == CALC_STATE_INPUT1)
            {
                // 输入第一个数（限制为0-9）
                num1 = digit;
            }
            else if (state == CALC_STATE_INPUT2)
            {
                // 输入第二个数（限制为0-9）
                num2 = digit;
            }
            else if (state == CALC_STATE_RESULT)
            {
                // 从结果状态重新开始
                num1 = digit;
                num2 = 0;
                operator = OP_NONE;
                state = CALC_STATE_INPUT1;
            }
        }
        else if (sel_type == SELECT_TYPE_OPERATOR)
        {
            // 选择的是运算符
            operator = GetSelectionOperator();
            
            if (state == CALC_STATE_INPUT1)
            {
                // 输入运算符后，进入输入第二个数的状态
                state = CALC_STATE_INPUT2;
                num2 = 0;
            }
            else if (state == CALC_STATE_INPUT2)
            {
                // 更改运算符
                // num2保持不变
            }
            else if (state == CALC_STATE_RESULT)
            {
                // 从结果状态开始新计算
                num1 = result;
                num2 = 0;
                state = CALC_STATE_INPUT2;
            }
        }
        else if (sel_type == SELECT_TYPE_EQUAL)
        {
            // 选择的是等号，执行计算
            if (state == CALC_STATE_INPUT2 && operator != OP_NONE)
            {
                // 如果还没有输入num2，num2保持为0
                Calculator_Calculate();
                state = CALC_STATE_RESULT;
            }
            else if (state == CALC_STATE_RESULT)
            {
                // 在结果状态下按等号，使用当前结果和运算符继续计算
                if (operator != OP_NONE)
                {
                    num1 = result;
                    Calculator_Calculate();
                }
            }
        }
        
        // 确认选择后，重置选择项到0，下次选择时从0开始
        current_selection = 0;
    }
    
    Calculator_Display();
    return 0;  // 继续计算器模式
}

void Calculator_Calculate(void)
{
    switch(operator)
    {
        case OP_ADD:
            result = num1 + num2;
            break;
        case OP_SUB:
            if (num1 >= num2)
                result = num1 - num2;
            else
                result = 0;  // 负数处理为0（正整数运算）
            break;
        case OP_MUL:
            result = num1 * num2;
            break;
        case OP_DIV:
            if (num2 != 0)
                result = num1 / num2;
            else
                result = 0;  // 除零错误
            break;
        default:
            result = num1;
            break;
    }
    
    // 限制结果在合理范围内（十以内正整数，但结果可能超过9）
    if (result > 9999) result = 9999;  // 限制显示范围
}

void Calculator_Display(void)
{
    unsigned char len1;
    char op_char;
    unsigned char col_pos;
    unsigned char sel_type;
    char sel_char;
    
    LcdClear();
    
    // 第一行显示计算表达式：num1 op num2
    sprintf(calc_buffer, "%lu", num1);
    WriteASCIIStr(0, 0, calc_buffer);
    len1 = strlen(calc_buffer);
    col_pos = len1;
    
    // 显示运算符
    if (operator != OP_NONE)
    {
        switch(operator)
        {
            case OP_ADD: op_char = '+'; break;
            case OP_SUB: op_char = '-'; break;
            case OP_MUL: op_char = '*'; break;
            case OP_DIV: op_char = '/'; break;
            default: op_char = '?'; break;
        }
        
        WriteChar(0, col_pos, op_char);
        col_pos++;
        
        // 显示第二个数
        if (state == CALC_STATE_INPUT2 || state == CALC_STATE_RESULT)
        {
            sprintf(calc_buffer, "%lu", num2);
            WriteASCIIStr(0, col_pos, calc_buffer);
        }
    }
    
    // 第二行显示结果（如果已计算）
    if (state == CALC_STATE_RESULT)
    {
        WriteASCIIStr(1, 0, "Result:");
        sprintf(calc_buffer, "%lu", result);
        WriteASCIIStr(1, 7, calc_buffer);
    }
    else
    {
        WriteASCIIStr(1, 0, "Expression:");
    }
    
    // 第三行显示当前选择项
    sel_type = GetSelectionType();
    if (sel_type == SELECT_TYPE_DIGIT)
    {
        sprintf(calc_buffer, "Select: %u", (unsigned int)current_selection);
        WriteASCIIStr(2, 0, calc_buffer);
    }
    else if (sel_type == SELECT_TYPE_OPERATOR)
    {
        switch(GetSelectionOperator())
        {
            case OP_ADD: sel_char = '+'; break;
            case OP_SUB: sel_char = '-'; break;
            case OP_MUL: sel_char = '*'; break;
            case OP_DIV: sel_char = '/'; break;
            default: sel_char = '?'; break;
        }
        sprintf(calc_buffer, "Select: %c", sel_char);
        WriteASCIIStr(2, 0, calc_buffer);
    }
    else
    {
        WriteASCIIStr(2, 0, "Select: =");
    }
    
    // 第四行显示按键提示
    WriteASCIIStr(3, 0, "R:Sel L:OK");
}
