#include "key.h"
#include "sysclk.h"
#include "port.h"
#include "C8051F020.h"

// 按键状态变量
unsigned char key_value = KEY_NONE;
unsigned char key_released = 0;  // 按键释放标志
unsigned char last_key_state = KEY_NONE;  // 上次按键状态

// 注意：key_pressed在main.c中定义（完全按照例程3的方式）

// 获取按键值（通过读取P5端口）
unsigned char GetKey(void)
{
    unsigned char p5_val = P5;
    
    // 根据P5端口值判断按键
    switch(p5_val)
    {
        case 0xFB:  // 左键
            return KEY_LEFT;
        case 0xFD:  // 中键
            return KEY_MIDDLE;
        case 0xFE:  // 右键
            return KEY_RIGHT;
        default:
            return KEY_NONE;
    }
}

// 检查是否有按键按下
// 注意：key_pressed在main.c中定义，需要extern声明
extern unsigned char key_pressed;

unsigned char KeyPressed(void)
{
    return key_pressed;
}

// 注意：INT1_ISR中断服务程序在main.c中定义（完全按照例程3--秒表的方式）
