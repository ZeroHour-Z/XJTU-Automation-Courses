#include "sysclk.h"
#include "time.h"
#include "alarm.h"

// 定时器重载值：10ms
#define TIMER0_RELOAD_HIGH 0xDC
#define TIMER0_RELOAD_LOW  0x00

unsigned int timer_count = 0;  // 定时器计数（10ms为单位）
DateTime current_time = {2025, 11, 14, 6, 59, 50};  // 初始时间：2024年1月1日 00:00:00

// 每月的天数（非闰年）
const unsigned char days_in_month[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

// 判断是否为闰年
unsigned char IsLeapYear(unsigned int year)
{
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
        return 1;
    return 0;
}

void Timer0_Init()
{
	TMOD = 0x01;               // 设置为16位模式
	TH0 = TIMER0_RELOAD_HIGH;  // 设置高8位
	TL0 = TIMER0_RELOAD_LOW;   // 设置低8位
	ET0 = 1;                   // 使能定时器0中断
}

// 外部声明：按键消抖处理函数（在main.c中定义）
extern void key_debounce_handler(void);

void Timer0_ISR(void) interrupt 1
{
	TH0 = TIMER0_RELOAD_HIGH;  // 重新加载定时器高8位
	TL0 = TIMER0_RELOAD_LOW;   // 重新加载定时器低8位
	
	timer_count++;
	
	// 每100次中断 = 1秒
	if (timer_count >= 100)
	{
		timer_count = 0;
		UpdateDateTime();
		// 检查闹钟时间（每秒检查一次）
		Alarm_CheckTime();
	}
	
	// 在定时器中断中处理按键消抖（每10ms执行一次，精确计时）
	key_debounce_handler();
}

void UpdateDateTime(void)
{
	current_time.second++;
	
	if (current_time.second >= 60)
	{
		current_time.second = 0;
		current_time.minute++;
		
		if (current_time.minute >= 60)
		{
			current_time.minute = 0;
			current_time.hour++;
			
			if (current_time.hour >= 24)
			{
				unsigned char max_days;  // 当前月份的最大天数
				
				current_time.hour = 0;
				current_time.day++;
				
				// 获取当前月份的最大天数
				max_days = days_in_month[current_time.month - 1];
				if (current_time.month == 2 && IsLeapYear(current_time.year))
					max_days = 29;
				
				if (current_time.day > max_days)
				{
					current_time.day = 1;
					current_time.month++;
					
					if (current_time.month > 12)
					{
						current_time.month = 1;
						current_time.year++;
					}
				}
			}
		}
	}
}

void InitDateTime(void)
{
	timer_count = 0;
}

