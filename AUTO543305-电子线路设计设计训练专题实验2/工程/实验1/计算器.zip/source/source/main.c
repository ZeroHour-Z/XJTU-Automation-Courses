#include "C8051F020.h"
#include "sysclk.h"
#include "port.h"
#include "time.h"
#include "lcd.h"
#include "digitron.h"
#include "key.h"
#include "calculator.h"
#include "calendar.h"
#include "alarm.h"

// 系统状态
#define SYSTEM_STATE_MENU       0  // 菜单状态
#define SYSTEM_STATE_CALC       1  // 计算器状态
#define SYSTEM_STATE_CALENDAR  2  // 日历状态
#define SYSTEM_STATE_ALARM     3  // 闹钟状态

unsigned char system_state = SYSTEM_STATE_MENU;
unsigned char menu_selection = 0;  // 0=计算器, 1=日历, 2=闹钟

sbit INT1_KEY = P0^3;   // INT1按键引脚

// 改进的按键消抖变量（使用定时器中断消抖）
unsigned char key_pressed = 0;           // 按键按下标志
unsigned char key_debounce_counter = 0;   // 消抖计数器（在定时器中断中递增）
unsigned char key_valid = 0;              // 按键有效标志（消抖完成后置1）
unsigned char last_key_value = 0xFF;      // 上次按键值（初始化为无效值0xFF）
unsigned char detected_key = 0xFF;
#define DEBOUNCE_TIME 2  // 消抖时间：2 * 10ms = 20ms（定时器中断每10ms一次）           

void Init_Device(void)
{
    EA = 0;        
    WDTCN = 0xde;  
    WDTCN = 0xad;
    EA = 1;        
    SYSCLK_Init(); 
    Port_IO_Init();
    Timer0_Init(); 
    Interrupt_Init();
    LcdInit();     
    InitDateTime();
    P5 = 0xFF;     
    P74OUT |= 0x01;
    P4 = 0xFD;     
}

void ShowMenu(void)
{
    LcdClear();
    WriteASCIIStr(0, 0, "Function Menu");
    
    if (menu_selection == 0)
    {
        WriteASCIIStr(1, 0, "> Calculator");
        WriteASCIIStr(2, 0, "  Calendar");
        WriteASCIIStr(3, 0, "  Alarm");
    }
    else if (menu_selection == 1)
    {
        WriteASCIIStr(1, 0, "  Calculator");
        WriteASCIIStr(2, 0, "> Calendar");
        WriteASCIIStr(3, 0, "  Alarm");
    }
    else
    {
        WriteASCIIStr(1, 0, "  Calculator");
        WriteASCIIStr(2, 0, "  Calendar");
        WriteASCIIStr(3, 0, "> Alarm");
    }
}

void key_debounce_handler(void)
{
    if(key_pressed)
    {
        key_debounce_counter++;
        if(key_debounce_counter >= DEBOUNCE_TIME)
        {
            key_valid = 1;
            key_pressed = 0;  // 清除按下标志，等待下次按下
            key_debounce_counter = 0;
        }
    }
    else
    {
        // 按键未按下，重置计数器
        key_debounce_counter = 0;
    }
}

void process_key(unsigned char key_val)
{
    // 只处理计算器模式的按键，日历模式的按键在主循环中直接处理
    if (system_state == SYSTEM_STATE_CALC)
    {
        unsigned char key;
        if (key_val == 0xFB) key = KEY_LEFT;
        else if (key_val == 0xFD) key = KEY_MIDDLE;
        else if (key_val == 0xFE) key = KEY_RIGHT;
        else key = KEY_NONE;
        if (key != KEY_NONE)
        {
            unsigned char need_return = Calculator_ProcessKey(key);
            
            if (need_return == 1)
            {
                system_state = SYSTEM_STATE_MENU;
                ShowMenu();
                ClearDigitron();
            }
        }
    }
}

void main(void)
{
    static unsigned char last_second = 255;
    unsigned char key_val;  // 按键值变量（C51要求在函数开头声明）
    
    Init_Device();
    Alarm_Init();  // 初始化闹钟
    system_state = SYSTEM_STATE_MENU;  
    TR0 = 1;       
    ShowMenu();    
    
    while(1)
    {
        // 检查闹钟是否正在响铃（无论当前在哪个状态）
        if (Alarm_IsRinging())
        {
            // 闹钟正在响铃，显示图片（已在Alarm_StartRinging中调用）
            // 这里不需要额外操作，图片会一直显示直到用户按中键停止
        }
        else if (system_state == SYSTEM_STATE_CALENDAR)
        {
            // 日历模式：显示时间（时:分）
            // 只在正常模式下自动更新，设置模式下不自动更新
            if (!Calendar_IsSetting() && current_time.second != last_second)
            {
                last_second = current_time.second;
                Calendar_Update();
            }
            
            // 如果不在设置模式，更新数码管显示
            if (!Calendar_IsSetting())
            {
                DisplayNumber(current_time.hour * 100 + current_time.minute);
            }
        }
        else if (system_state == SYSTEM_STATE_ALARM)
        {
            // 闹钟模式：如果不在设置模式且不在响铃，显示闹钟时间
            if (!Alarm_IsSetting() && !Alarm_IsRinging())
            {
                DisplayNumber(alarm_time.hour * 100 + alarm_time.minute);
            }
        }
        else if (system_state == SYSTEM_STATE_CALC)
        {
            // 计算器模式：显示当前输入的数字
            if (state == CALC_STATE_INPUT1)
            {
                if (current_selection < 10)
                    DisplayNumber((int)current_selection);
                else
                    DisplayNumber((int)num1);
            }
            else if (state == CALC_STATE_INPUT2)
            {
                if (current_selection < 10)
                    DisplayNumber((int)current_selection);
                else
                    DisplayNumber((int)num2);
            }
            else if (state == CALC_STATE_RESULT)
            {
                if (result > 9999)
                    DisplayNumber(9999);
                else
                    DisplayNumber((int)result);
            }
        }
        else
        {
            DisplayNumber(0);  
        }
        
        if(key_valid)
        {
            key_valid = 0;  // 清除有效标志
            
            // 直接使用中断服务程序中保存的按键值
            key_val = last_key_value;
            
            // 根据按键值处理
            switch(key_val)
            {
                case 0xFB:  // 左键
                    if (system_state == SYSTEM_STATE_MENU)
                    {
                        if (menu_selection > 0)
                            menu_selection--;
                        else
                            menu_selection = 2;  // 循环到闹钟
                        ShowMenu();
                    }
                    else if (system_state == SYSTEM_STATE_CALC)
                    {
                        // 计算器模式：使用原来的方式
                        process_key(0xFB);
                    }
                    else if (system_state == SYSTEM_STATE_CALENDAR)
                    {
                        // 日历模式：直接处理按键，使用数值1（KEY_LEFT）
                        unsigned char need_return = Calendar_ProcessKey(1);
                        if (need_return == 1)
                        {
                            system_state = SYSTEM_STATE_MENU;
                            ShowMenu();
                            ClearDigitron();
                        }
                    }
                    else if (system_state == SYSTEM_STATE_ALARM)
                    {
                        // 闹钟模式：处理按键
                        unsigned char need_return = Alarm_ProcessKey(1);
                        if (need_return == 1)
                        {
                            system_state = SYSTEM_STATE_MENU;
                            ShowMenu();
                            ClearDigitron();
                        }
                    }
                    break;
                    
                case 0xFD:   // 中键
                    if (system_state == SYSTEM_STATE_MENU)
                    {
                        if (menu_selection == 0)
                        {
                            system_state = SYSTEM_STATE_CALC;
                            Calculator_Init();
                        }
                        else if (menu_selection == 1)
                        {
                            system_state = SYSTEM_STATE_CALENDAR;
                            Calendar_Init();
                        }
                        else  // menu_selection == 2
                        {
                            system_state = SYSTEM_STATE_ALARM;
                            Alarm_Init();
                            Alarm_ExitSetting();  // 显示闹钟界面
                        }
                    }
                    else if (system_state == SYSTEM_STATE_ALARM || Alarm_IsRinging())
                    {
                        // 闹钟模式：处理按键（包括响铃状态）
                        unsigned char need_return = Alarm_ProcessKey(2);
                        if (need_return == 1)
                        {
                            system_state = SYSTEM_STATE_MENU;
                            ShowMenu();
                            ClearDigitron();
                        }
                    }
                    else if (system_state == SYSTEM_STATE_CALC)
                    {
                        // 计算器模式：使用原来的方式
                        process_key(0xFD);
                    }
                    else if (system_state == SYSTEM_STATE_CALENDAR)
                    {
                        // 日历模式：直接处理按键，使用数值2（KEY_MIDDLE）
                        unsigned char need_return = Calendar_ProcessKey(2);
                        if (need_return == 1)
                        {
                            system_state = SYSTEM_STATE_MENU;
                            ShowMenu();
                            ClearDigitron();
                        }
                    }
                    break;	
                
                case 0xFE:    // 右键
                    if (system_state == SYSTEM_STATE_MENU)
                    {
                        if (menu_selection < 2)
                            menu_selection++;
                        else
                            menu_selection = 0;  // 循环到计算器
                        ShowMenu();
                    }
                    else if (system_state == SYSTEM_STATE_ALARM)
                    {
                        // 闹钟模式：处理按键
                        unsigned char need_return = Alarm_ProcessKey(3);
                        if (need_return == 1)
                        {
                            system_state = SYSTEM_STATE_MENU;
                            ShowMenu();
                            ClearDigitron();
                        }
                    }
                    else if (system_state == SYSTEM_STATE_CALC)
                    {
                        // 计算器模式：使用原来的方式
                        process_key(0xFE);
                    }
                    else if (system_state == SYSTEM_STATE_CALENDAR)
                    {
                        // 日历模式：直接处理按键，使用数值3（KEY_RIGHT）
                        unsigned char need_return = Calendar_ProcessKey(3);
                        if (need_return == 1)
                        {
                            system_state = SYSTEM_STATE_MENU;
                            ShowMenu();
                            ClearDigitron();
                        }
                    }
                    break;
            }
        }
    }
}

// INT1中断服务程序（改进版：使用位检查识别按键）
void INT1_ISR(void) interrupt 2
{
    if(INT1_KEY == 0)
    {
        unsigned char key_val = P5;
        unsigned char valid_key = 0xFF;
        unsigned char i;
        for(i = 0; i < 10; i++);
        key_val = P5;
        if(key_val == 0xFB || key_val == 0xFD || key_val == 0xFE)
        {
            valid_key = key_val;
        }
        else
        {
            if ((key_val & 0x04) == 0)
            {
                valid_key = 0xFB;
            }
            else if ((key_val & 0x02) == 0)
            {
                valid_key = 0xFD;
            }
            else if ((key_val & 0x01) == 0)
            {
                valid_key = 0xFE;
            }
        }
        if(valid_key != 0xFF)
        {
            // 如果按键值改变，重新开始消抖
            if(1)
            {
                key_pressed = 1;        // 设置按下标志，开始消抖
                key_debounce_counter = 0; // 重置计数器
                key_valid = 0;          // 清除有效标志
                last_key_value = valid_key; // 保存按键值
            }
        }
        while(INT1_KEY == 0);
    }
    else
    {
        if(last_key_value != 0xFF)
        {
            last_key_value = 0xFF;  // 重置为无效值，下次按键时重新识别
        }
    }

}
