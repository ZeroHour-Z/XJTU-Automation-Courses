#include "calendar.h"
#include "lcd.h"
#include "digitron.h"
#include "time.h"
#include "key.h"
#include "C8051F020.h"
#include <stdio.h>

char xdata date_buffer[32];
char xdata time_buffer[32];

// 日历设置状态变量
static unsigned char calendar_mode = CALENDAR_NORMAL;  // 日历模式：正常/设置
static unsigned char setting_field = SET_FIELD_YEAR;   // 当前设置的字段


void Calendar_Init(void)
{
    calendar_mode = CALENDAR_NORMAL;
    setting_field = SET_FIELD_YEAR;
    LcdClear();
    WriteASCIIStr(0, 0, "Calendar");
    Calendar_Display();
}

void Calendar_Display(void)
{
    // 先清空要显示的行
    LineClear(0);
    LineClear(1);
    LineClear(2);
    LineClear(3);
    
    // 显示标题
    WriteASCIIStr(0, 0, "Calendar");
    
    // 显示日期（使用ASCII字符串显示函数，确保类型匹配）
    sprintf(date_buffer, "%04u-%02u-%02u", 
            (unsigned int)current_time.year, 
            (unsigned int)current_time.month, 
            (unsigned int)current_time.day);
    WriteASCIIStr(1, 0, date_buffer);
    
    // 显示时间（使用ASCII字符串显示函数）
    sprintf(time_buffer, "%02u:%02u:%02u", 
            (unsigned int)current_time.hour, 
            (unsigned int)current_time.minute, 
            (unsigned int)current_time.second);
    WriteASCIIStr(2, 0, time_buffer);
    
    // 显示按键提示
    WriteASCIIStr(3, 0, "Mid:Exit R:Set");
    
    // 数码管显示时间（时:分）
    DisplayNumber(current_time.hour * 100 + current_time.minute);
}

void Calendar_Update(void)
{
    if (calendar_mode == CALENDAR_NORMAL)
    {
        // 只更新时间部分（秒会变化），先清空时间行
        LineClear(2);
        
        // 显示时间（使用ASCII字符串显示函数）
        sprintf(time_buffer, "%02u:%02u:%02u", 
                (unsigned int)current_time.hour, 
                (unsigned int)current_time.minute, 
                (unsigned int)current_time.second);
        WriteASCIIStr(2, 0, time_buffer);
        
        // 数码管显示时间（时:分）
        DisplayNumber(current_time.hour * 100 + current_time.minute);
    }
}

unsigned char Calendar_IsSetting(void)
{
    return calendar_mode == CALENDAR_SETTING;
}

void Calendar_EnterSetting(void)
{
    // 确保状态被正确设置
    calendar_mode = CALENDAR_SETTING;
    setting_field = SET_FIELD_YEAR;
    // 立即显示设置界面
    Calendar_SettingDisplay();
}

void Calendar_ExitSetting(void)
{
    calendar_mode = CALENDAR_NORMAL;
    Calendar_Display();
}

void Calendar_SettingDisplay(void)
{
    unsigned char max_days;
    
    // 清空显示
    LineClear(0);
    LineClear(1);
    LineClear(2);
    LineClear(3);
    
    // 显示标题
    WriteASCIIStr(0, 0, "Calendar Setting");
    
    // 根据当前选择的字段显示对应的设置界面
    switch(setting_field)
    {
        case SET_FIELD_YEAR:
            sprintf(date_buffer, "Year: %04u", (unsigned int)current_time.year);
            WriteASCIIStr(1, 0, date_buffer);
            WriteASCIIStr(2, 0, "L:Dec R:Inc");
            WriteASCIIStr(3, 0, "M:Next");
            DisplayNumber((int)current_time.year);
            break;
            
        case SET_FIELD_MONTH:
            sprintf(date_buffer, "Month: %02u", (unsigned int)current_time.month);
            WriteASCIIStr(1, 0, date_buffer);
            WriteASCIIStr(2, 0, "L:Dec R:Inc");
            WriteASCIIStr(3, 0, "M:Next");
            DisplayNumber((int)current_time.month);
            break;
            
        case SET_FIELD_DAY:
            // 计算当前月份的最大天数
            max_days = days_in_month[current_time.month - 1];
            if (current_time.month == 2 && IsLeapYear(current_time.year))
                max_days = 29;
            
            sprintf(date_buffer, "Day: %02u/%02u", 
                    (unsigned int)current_time.day, (unsigned int)max_days);
            WriteASCIIStr(1, 0, date_buffer);
            WriteASCIIStr(2, 0, "L:Dec R:Inc");
            WriteASCIIStr(3, 0, "M:Next");
            DisplayNumber((int)current_time.day);
            break;
            
        case SET_FIELD_HOUR:
            sprintf(time_buffer, "Hour: %02u", (unsigned int)current_time.hour);
            WriteASCIIStr(1, 0, time_buffer);
            WriteASCIIStr(2, 0, "L:Dec R:Inc");
            WriteASCIIStr(3, 0, "M:Next");
            DisplayNumber((int)current_time.hour);
            break;
            
        case SET_FIELD_MINUTE:
            sprintf(time_buffer, "Minute: %02u", (unsigned int)current_time.minute);
            WriteASCIIStr(1, 0, time_buffer);
            WriteASCIIStr(2, 0, "L:Dec R:Inc");
            WriteASCIIStr(3, 0, "M:Next");
            DisplayNumber((int)current_time.minute);
            break;
            
        case SET_FIELD_SECOND:
            sprintf(time_buffer, "Second: %02u", (unsigned int)current_time.second);
            WriteASCIIStr(1, 0, time_buffer);
            WriteASCIIStr(2, 0, "L:Dec R:Inc");
            WriteASCIIStr(3, 0, "M:Next");
            DisplayNumber((int)current_time.second);
            break;
            
        case SET_FIELD_EXIT:
            WriteASCIIStr(1, 0, "Exit Setting?");
            WriteASCIIStr(2, 0, "M:Confirm");
            WriteASCIIStr(3, 0, "L/R:Cancel");
            DisplayNumber(9999);
            break;
    }
}

unsigned char Calendar_ProcessKey(unsigned char key)
{
    unsigned char max_days;
    unsigned char need_return = 0;
    if (calendar_mode == CALENDAR_SETTING)
    {
        switch(setting_field)
        {
            case SET_FIELD_YEAR:
                if (key == 1 || key == KEY_LEFT)  // KEY_LEFT
                {
                    if (current_time.year > 2000)
                        current_time.year--;
                    else
                        current_time.year = 2099;
                    Calendar_SettingDisplay();
                }
                else if (key == 2 || key == KEY_MIDDLE)  // KEY_MIDDLE
                {
                    setting_field = SET_FIELD_MONTH;
                    Calendar_SettingDisplay();
                }
                else if (key == 3 || key == KEY_RIGHT)  // KEY_RIGHT
                {
                    if (current_time.year < 2099)
                        current_time.year++;
                    else
                        current_time.year = 2000;
                    Calendar_SettingDisplay();
                }
                break;
                
            case SET_FIELD_MONTH:
                switch(key)
                {
                    case 1:  // KEY_LEFT
                        // 左键：减少月份
                        if (current_time.month > 1)
                            current_time.month--;
                        else
                            current_time.month = 12;
                        Calendar_SettingDisplay();
                        break;
                    case 2:  // KEY_MIDDLE
                        // 中键：切换到下一个字段（日）
                        setting_field = SET_FIELD_DAY;
                        Calendar_SettingDisplay();
                        break;
                    case 3:  // KEY_RIGHT
                        // 右键：增加月份
                        if (current_time.month < 12)
                            current_time.month++;
                        else
                            current_time.month = 1;
                        Calendar_SettingDisplay();
                        break;
                    default:
                        break;
                }
                break;
                
            case SET_FIELD_DAY:
                // 计算当前月份的最大天数
                max_days = days_in_month[current_time.month - 1];
                if (current_time.month == 2 && IsLeapYear(current_time.year))
                    max_days = 29;
                
                switch(key)
                {
                    case 1:  // KEY_LEFT
                        // 左键：减少日期
                        if (current_time.day > 1)
                            current_time.day--;
                        else
                            current_time.day = max_days;
                        Calendar_SettingDisplay();
                        break;
                    case 2:  // KEY_MIDDLE
                        // 中键：切换到下一个字段（时）
                        setting_field = SET_FIELD_HOUR;
                        Calendar_SettingDisplay();
                        break;
                    case 3:  // KEY_RIGHT
                        // 右键：增加日期
                        if (current_time.day < max_days)
                            current_time.day++;
                        else
                            current_time.day = 1;
                        Calendar_SettingDisplay();
                        break;
                    default:
                        break;
                }
                break;
                
            case SET_FIELD_HOUR:
                switch(key)
                {
                    case 1:  // KEY_LEFT
                        // 左键：减少小时
                        if (current_time.hour > 0)
                            current_time.hour--;
                        else
                            current_time.hour = 23;
                        Calendar_SettingDisplay();
                        break;
                    case 2:  // KEY_MIDDLE
                        // 中键：切换到下一个字段（分）
                        setting_field = SET_FIELD_MINUTE;
                        Calendar_SettingDisplay();
                        break;
                    case 3:  // KEY_RIGHT
                        // 右键：增加小时
                        if (current_time.hour < 23)
                            current_time.hour++;
                        else
                            current_time.hour = 0;
                        Calendar_SettingDisplay();
                        break;
                    default:
                        break;
                }
                break;
                
            case SET_FIELD_MINUTE:
                switch(key)
                {
                    case 1:  // KEY_LEFT
                        // 左键：减少分钟
                        if (current_time.minute > 0)
                            current_time.minute--;
                        else
                            current_time.minute = 59;
                        Calendar_SettingDisplay();
                        break;
                    case 2:  // KEY_MIDDLE
                        // 中键：切换到下一个字段（秒）
                        setting_field = SET_FIELD_SECOND;
                        Calendar_SettingDisplay();
                        break;
                    case 3:  // KEY_RIGHT
                        // 右键：增加分钟
                        if (current_time.minute < 59)
                            current_time.minute++;
                        else
                            current_time.minute = 0;
                        Calendar_SettingDisplay();
                        break;
                    default:
                        break;
                }
                break;
                
            case SET_FIELD_SECOND:
                switch(key)
                {
                    case 1:  // KEY_LEFT
                        // 左键：减少秒数
                        if (current_time.second > 0)
                            current_time.second--;
                        else
                            current_time.second = 59;
                        Calendar_SettingDisplay();
                        break;
                    case 2:  // KEY_MIDDLE
                        // 中键：切换到退出确认
                        setting_field = SET_FIELD_EXIT;
                        Calendar_SettingDisplay();
                        break;
                    case 3:  // KEY_RIGHT
                        // 右键：增加秒数
                        if (current_time.second < 59)
                            current_time.second++;
                        else
                            current_time.second = 0;
                        Calendar_SettingDisplay();
                        break;
                    default:
                        break;
                }
                break;
                
            case SET_FIELD_EXIT:
                switch(key)
                {
                    case 1:  // KEY_LEFT
                    case 3:  // KEY_RIGHT
                        // 取消退出，返回设置秒
                        setting_field = SET_FIELD_SECOND;
                        Calendar_SettingDisplay();
                        break;
                    case 2:  // KEY_MIDDLE
                        // 确认退出设置
                        Calendar_ExitSetting();
                        break;
                    default:
                        break;
                }
                break;
                
            default:
                // 未知的字段，重置为年份
                setting_field = SET_FIELD_YEAR;
                Calendar_SettingDisplay();
                break;
        }
    }
    else
    {
        if (key == 3 || key == KEY_RIGHT)  // KEY_RIGHT = 3
        {
            Calendar_EnterSetting();
            return 0;
        }
        else if (key == 2 || key == KEY_MIDDLE)  // KEY_MIDDLE = 2
        {
            need_return = 1;
        }
    }
    
    return need_return;
}

