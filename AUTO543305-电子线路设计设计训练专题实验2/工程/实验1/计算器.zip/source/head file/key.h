#ifndef KEY_H
#define KEY_H

// 按键定义
#define KEY_NONE    0
#define KEY_LEFT    1   // 左键：0xFB
#define KEY_MIDDLE  2   // 中键：0xFD
#define KEY_RIGHT   3   // 右键：0xFE
#define KEY_0       10
#define KEY_1       11
#define KEY_2       12
#define KEY_3       13
#define KEY_4       14
#define KEY_5       15
#define KEY_6       16
#define KEY_7       17
#define KEY_8       18
#define KEY_9       19
#define KEY_ADD     20   // 加号 +
#define KEY_SUB     21   // 减号 -
#define KEY_MUL     22   // 乘号 *
#define KEY_DIV     23   // 除号 /
#define KEY_EQUAL   24   // 等号 =
#define KEY_CLEAR   25   // 清除 C

extern unsigned char key_value;         // 当前按键值
extern unsigned char key_pressed;       // 按键按下标志
extern unsigned char key_released;     // 按键释放标志
extern unsigned char last_key_state;   // 上次按键状态

unsigned char GetKey(void);              // 获取按键值
unsigned char KeyPressed(void);          // 检查是否有按键按下
// 注意：KeyScan()已不再使用，按键处理在中断服务程序中完成

#endif

