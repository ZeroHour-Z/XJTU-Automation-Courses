#ifndef DIGITRON_H
#define DIGITRON_H
#include "C8051F020.h"

void DisplayNumber(int num);           // 在数码管上显示数字（4位）
void DisplayNumber8(int num);           // 在8位数码管上显示数字
void ClearDigitron(void);              // 清空数码管显示

#endif

