#ifndef CALCULATOR_H
#define CALCULATOR_H

// 计算器状态
#define CALC_STATE_INPUT1    0  // 输入第一个数
#define CALC_STATE_OPERATOR  1  // 输入运算符
#define CALC_STATE_INPUT2    2  // 输入第二个数
#define CALC_STATE_RESULT    3  // 显示结果

// 运算符
#define OP_NONE   0
#define OP_ADD    1  // +
#define OP_SUB    2  // -
#define OP_MUL    3  // *
#define OP_DIV    4  // /

void Calculator_Init(void);                    // 初始化计算器
unsigned char Calculator_ProcessKey(unsigned char key); // 处理按键，返回1表示需要返回菜单
void Calculator_Display(void);                 // 显示计算过程
void Calculator_Calculate(void);              // 执行计算

extern unsigned long xdata num1;      // 第一个数（0-9）
extern unsigned long xdata num2;      // 第二个数（0-9）
extern unsigned long xdata result;    // 结果
extern unsigned char xdata operator;  // 运算符
extern unsigned char xdata state;     // 当前状态
extern unsigned char xdata current_selection;  // 当前选择项（0-14：0-9是数字，10=+, 11=-, 12=*, 13=/, 14==）

#endif

