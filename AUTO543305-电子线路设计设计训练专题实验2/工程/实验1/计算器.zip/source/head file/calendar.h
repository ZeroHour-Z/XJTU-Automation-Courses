#ifndef CALENDAR_H
#define CALENDAR_H

#include "time.h"

// 日历设置模式状态
#define CALENDAR_NORMAL     0  // 正常显示模式
#define CALENDAR_SETTING    1  // 设置模式

// 设置字段选择
#define SET_FIELD_YEAR      0  // 设置年
#define SET_FIELD_MONTH     1  // 设置月
#define SET_FIELD_DAY       2  // 设置日
#define SET_FIELD_HOUR      3  // 设置时
#define SET_FIELD_MINUTE    4  // 设置分
#define SET_FIELD_SECOND    5  // 设置秒
#define SET_FIELD_EXIT      6  // 退出设置

void Calendar_Init(void);           // 初始化日历
void Calendar_Display(void);        // 显示日历
void Calendar_Update(void);         // 更新显示（每秒调用）
unsigned char Calendar_ProcessKey(unsigned char key);  // 处理按键（返回1表示需要退出）
void Calendar_EnterSetting(void);   // 进入设置模式
void Calendar_ExitSetting(void);    // 退出设置模式
void Calendar_SettingDisplay(void); // 显示设置界面
unsigned char Calendar_IsSetting(void);  // 判断是否在设置模式

#endif

