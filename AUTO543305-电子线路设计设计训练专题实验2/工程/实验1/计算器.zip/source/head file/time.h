#ifndef TIME_H
#define TIME_H

// 日历时间结构
typedef struct {
    unsigned int year;
    unsigned char month;
    unsigned char day;
    unsigned char hour;
    unsigned char minute;
    unsigned char second;
} DateTime;

extern unsigned int timer_count;  // 定时器计数（10ms为单位）
extern DateTime current_time;     // 当前时间
extern const unsigned char days_in_month[];  // 每月的天数数组

void Timer0_Init(void);
void Timer0_ISR(void);
void UpdateDateTime(void);       // 更新时间
void InitDateTime(void);         // 初始化时间（只重置定时器计数，初始时间在结构体定义时设置）
unsigned char IsLeapYear(unsigned int year);  // 判断是否为闰年

#endif

