#ifndef ALARM_H
#define ALARM_H

#include "time.h"

// 闹钟状态
#define ALARM_OFF    0  // 闹钟关闭
#define ALARM_ON     1  // 闹钟开启

// 闹钟设置字段
#define ALARM_SET_HOUR    0  // 设置时
#define ALARM_SET_MINUTE  1  // 设置分
#define ALARM_SET_EXIT    2  // 退出设置

extern unsigned char alarm_enabled;     // 闹钟是否开启（0=关闭，1=开启）
extern DateTime alarm_time;              // 闹钟时间
extern unsigned char alarm_ringing;      // 闹钟是否正在响铃（0=否，1=是）

void Alarm_Init(void);                           // 初始化闹钟
void Alarm_Enable(void);                         // 开启闹钟
void Alarm_Disable(void);                        // 关闭闹钟
unsigned char Alarm_IsEnabled(void);             // 检查闹钟是否开启
unsigned char Alarm_IsRinging(void);             // 检查闹钟是否正在响铃
void Alarm_CheckTime(void);                      // 检查是否到达闹钟时间
void Alarm_StartRinging(void);                   // 开始响铃（蜂鸣器+显示图片）
void Alarm_StopRinging(void);                    // 停止响铃
void Alarm_EnterSetting(void);                   // 进入闹钟设置模式
void Alarm_ExitSetting(void);                    // 退出闹钟设置模式
unsigned char Alarm_IsSetting(void);             // 判断是否在设置模式
void Alarm_SettingDisplay(void);                 // 显示闹钟设置界面
unsigned char Alarm_ProcessKey(unsigned char key);  // 处理按键（返回1表示需要退出）

#endif

