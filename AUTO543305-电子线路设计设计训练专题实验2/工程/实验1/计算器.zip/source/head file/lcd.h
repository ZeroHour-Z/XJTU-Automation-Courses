#ifndef LCD_H
#define LCD_H

#include "C8051F020.h"
#include <intrins.h>
#include <stdio.h>

void Lcd_Port_Init(void);
void LcdInit(void);

void Delay(uint k);

void SendByte(uchar Dbyte);
uchar ReceiveByte(void);
void CheckBusy(void);

void WriteData(uchar WDLCM);
void WriteCommand (uchar Cbyte);

void LineClear(uchar l);
void LcdClear( void );

void WriteChar(uchar row,uchar col,uchar ch);
void WriteStr(uchar row,uchar col,uchar *puts);
void WriteASCIIStr(uchar row,uchar col,char *puts);  // 显示ASCII字符串（用于日期、时间等）

void ImageShow(uchar *imagePtr);
void ImageShow1(uchar *imagePtr);
#endif

