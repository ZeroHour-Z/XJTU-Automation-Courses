#ifndef SYSCLK_H
#define SYSCLK_H
#include "C8051F020.h"
#define SYSCLK 11059200
#define SAMPLERATE0 50000

void SYSCLK_Init (void);
void Delay_us(unsigned int times);
void Delay_ms(unsigned int times);
void SimpleBeep(void);  // 蜂鸣器简单鸣叫

#endif

