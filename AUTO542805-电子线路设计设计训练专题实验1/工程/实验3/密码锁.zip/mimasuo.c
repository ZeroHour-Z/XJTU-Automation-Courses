#include <reg52.h>
#include <intrins.h>
sbit LCD_RS = P3^2;
sbit LCD_RW = P3^1;
sbit LCD_EN = P3^0;
#define LCD_DATA P2
sbit Buzzer = P3^3;
sbit Lock_Relay = P3^4;

unsigned char code DIG_CODE[11] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x00};
unsigned char InputPassword[4] = {10, 10, 10, 10};
unsigned char TempPassword[4] = {10, 10, 10, 10};
unsigned char CorrectPassword[4] = {1, 2, 3, 4};
unsigned char InputCount = 0; 
unsigned char ErrorCount = 0; 
bit LockFlag = 0;                                
bit SettingMode = 0;                            
bit FirstInputDone = 0;                       

unsigned char code AlarmMusicData[] = {
    0x18, 0x30, 0x1C , 0x10,    
    0x20, 0x40, 0x1C , 0x10,   
    0x18, 0x10, 0x20 , 0x10,   
    0x1C, 0x10, 0x18 , 0x40,
    0x00
};
unsigned char g_beat = 0; 
void DelayMS(unsigned int ms) {
    unsigned int i, j;
    for(i = 0; i < ms; i++)
        for(j = 0; j < 123; j++);
}
void InitTimer0() {
    TMOD = 0x01;
    TH0 = 0xD8; 
    TL0 = 0xEF;
    ET0 = 1;     
    EA = 1;     
}
void Timer0_ISR() interrupt 1 {
    TH0 = 0xD8;
    TL0 = 0xEF;
    if(g_beat > 0) {
        g_beat--;
    }
}
void AudioFrequencyDelay(unsigned char m) {
    unsigned int i = 3 * m;
    while(--i);
}
void BeepTone(unsigned char tone, unsigned char beat) {
    g_beat = beat;
    TR0 = 1;
    
    while(g_beat != 0) {
        Buzzer = ~Buzzer;
        AudioFrequencyDelay(tone);
    }
    TR0 = 0;  
}
void PlayMusic(unsigned char code *music_tab) {
    unsigned char i = 0;
    unsigned char tmpTone = 0;
    
    while(1) {
        tmpTone = music_tab[i];
        if(tmpTone == 0x00) {
            return;
        }
        else if(tmpTone == 0xFF) {
            ++i;
            DelayMS(100);
            TR0 = 0;
            continue;
        }
        else {
            unsigned char tone, beat;
            tone = music_tab[i++];
            beat = music_tab[i++];
            BeepTone(tone, beat);
        }
    }
}
bit LCD_CheckBusy() {
    LCD_DATA = 0xFF;
    LCD_RS = 0;
    LCD_RW = 1;
    LCD_EN = 1;
    _nop_();
    _nop_();
    if(LCD_DATA & 0x80) {
        LCD_EN = 0;
        return 1;
    }
    LCD_EN = 0;
    return 0;
}

void LCD_WriteCmd(unsigned char cmd) {
    while(LCD_CheckBusy());
    LCD_RS = 0;
    LCD_RW = 0;
    LCD_DATA = cmd;
    LCD_EN = 1;
    _nop_();
    _nop_();
    LCD_EN = 0;
}

void LCD_WriteData(unsigned char dat) {
    while(LCD_CheckBusy());
    LCD_RS = 1;
    LCD_RW = 0;
    LCD_DATA = dat;
    LCD_EN = 1;
    _nop_();
    _nop_();
    LCD_EN = 0;
}

void LCD_Init() {
    DelayMS(15);
    LCD_WriteCmd(0x38);  
    DelayMS(5);
    LCD_WriteCmd(0x38);
    DelayMS(5);
    LCD_WriteCmd(0x38);
    LCD_WriteCmd(0x08);  
    LCD_WriteCmd(0x01);  
    LCD_WriteCmd(0x06);  
    LCD_WriteCmd(0x0C);  
}

void LCD_SetPos(unsigned char x, unsigned char y) {
    unsigned char pos;
    if(y == 0)
        pos = 0x80 + x;
    else
        pos = 0xC0 + x;
    LCD_WriteCmd(pos);
}

void LCD_ShowString(unsigned char x, unsigned char y, unsigned char *str) {
    LCD_SetPos(x, y);
    while(*str != '\0') {
        LCD_WriteData(*str);
        str++;
    }
}

void LCD_ShowPassword() {
    unsigned char i;
    LCD_SetPos(0, 1);
    LCD_WriteData('P');
    LCD_WriteData('W');
    LCD_WriteData(':');
    LCD_WriteData(' ');
    for(i = 0; i < 4; i++) {
        if(InputPassword[i] < 10)
            LCD_WriteData('*');
        else
            LCD_WriteData('_');
    }
    for(i = 4; i < 16; i++) {
        LCD_WriteData(' ');
    }
}

void DisplayDigit() {
    if(InputCount > 0 && InputCount <= 4) {
        P0 = DIG_CODE[InputPassword[InputCount-1]];
    } else {
        P0 = DIG_CODE[10];
    }
}

unsigned char KeyScan() {
    unsigned char key_value = 16;
    unsigned char temp;
    P1 = 0xEF;
    temp = P1;
    temp = temp & 0x0F;
    if(temp != 0x0F) {
        DelayMS(10);
        temp = P1;
        temp = temp & 0x0F;
        if(temp != 0x0F) {
            switch(temp) {
                case 0x0E: key_value = 0; break; 
                case 0x0D: key_value = 1; break; 
                case 0x0B: key_value = 2; break;
                case 0x07: key_value = 3; break; 
            }
            while((P1 & 0x0F) != 0x0F);
            return key_value;
        }
    }
    P1 = 0xDF; 
    temp = P1;
    temp = temp & 0x0F;
    if(temp != 0x0F) {
        DelayMS(10);
        temp = P1;
        temp = temp & 0x0F;
        if(temp != 0x0F) {
            switch(temp) {
                case 0x0E: key_value = 4; break;
                case 0x0D: key_value = 5; break; 
                case 0x0B: key_value = 6; break;
                case 0x07: key_value = 7; break;
            }
            while((P1 & 0x0F) != 0x0F);
            return key_value;
        }
    }
    P1 = 0xBF; 
    temp = P1;
    temp = temp & 0x0F;
    if(temp != 0x0F) {
        DelayMS(10);
        temp = P1;
        temp = temp & 0x0F;
        if(temp != 0x0F) {
            switch(temp) {
                case 0x0E: key_value = 8; break;
                case 0x0D: key_value = 9; break;
                case 0x0B: key_value = 10; break;
                case 0x07: key_value = 11; break; 
            }
            while((P1 & 0x0F) != 0x0F);
            return key_value;
        }
    }
    P1 = 0x7F;
    temp = P1;
    temp = temp & 0x0F;
    if(temp != 0x0F) {
        DelayMS(10);
        temp = P1;
        temp = temp & 0x0F;
        if(temp != 0x0F) {
            switch(temp) {
                case 0x0E: key_value = 12; break;
                case 0x0D: key_value = 13; break;
                case 0x0B: key_value = 14; break;
                case 0x07: key_value = 15; break;
            }
            while((P1 & 0x0F) != 0x0F);
            return key_value;
        }
    }
    
    return 16;
}
void AlarmMusic() {
    PlayMusic(AlarmMusicData);
}
void Unlock() {
    unsigned char i;
    Lock_Relay = 1;
    LCD_ShowString(0, 0, "UNLOCK SUCCESS   ");
    LCD_ShowString(0, 1, "                 ");
    for(i = 0; i < 3; i++) {
        P0 = DIG_CODE[0]; 
        DelayMS(300);
        P0 = DIG_CODE[10];
        DelayMS(100);
        P0 = DIG_CODE[7];
        DelayMS(300);
        P0 = DIG_CODE[10];
        DelayMS(100);
        P0 = DIG_CODE[5];
        DelayMS(300);
        P0 = DIG_CODE[10]; 
        DelayMS(100);
        P0 = DIG_CODE[4]; 
        DelayMS(300);
        P0 = DIG_CODE[10];
        DelayMS(100);
    }
    DelayMS(2000); 
    Lock_Relay = 0;
}
bit CheckPassword() {
    unsigned char i;
    for(i = 0; i < 4; i++) {
        if(InputPassword[i] != CorrectPassword[i])
            return 0;
    }
    return 1;
}
void ResetSystem() {
    unsigned char i;
    for(i = 0; i < 4; i++) {
        InputPassword[i] = 10;
    }
    InputCount = 0;
    P0 = DIG_CODE[10];
    LCD_ShowPassword();
}
bit ComparePasswords() {
    unsigned char i;
    for(i = 0; i < 4; i++) {
        if(InputPassword[i] != TempPassword[i])
            return 0;
    }
    return 1;
}
void SetNewPassword() {
    unsigned char i;
    SettingMode = 1;
    FirstInputDone = 0;
    LCD_ShowString(0, 0, "SET NEW PASSWORD ");
    LCD_ShowString(0, 1, "1ST: ENTER 4 DIG ");
    
    InputCount = 0;
    for(i = 0; i < 4; i++) {
        InputPassword[i] = 10;
        TempPassword[i] = 10;
    }
    while(InputCount < 4) {
        unsigned char key = KeyScan();
        if(key < 10) {
            InputPassword[InputCount] = key;
            InputCount++;
            DisplayDigit();
            LCD_ShowPassword();
            DelayMS(300);
        }
    }
    for(i = 0; i < 4; i++) {
        TempPassword[i] = InputPassword[i];
    }
    FirstInputDone = 1;
    LCD_ShowString(0, 0, "SET NEW PASSWORD ");
    LCD_ShowString(0, 1, "2ND: ENTER 4 DIG ");
    
    InputCount = 0;
    for(i = 0; i < 4; i++) {
        InputPassword[i] = 10;
    }
    while(InputCount < 4) {
        unsigned char key = KeyScan();
        if(key < 10) {
            InputPassword[InputCount] = key;
            InputCount++;
            DisplayDigit();
            LCD_ShowPassword();
            DelayMS(300);
        }
    }
    if(ComparePasswords()) {
        for(i = 0; i < 4; i++) {
            CorrectPassword[i] = InputPassword[i];
        }
        
        LCD_ShowString(0, 0, "PASSWORD SET OK! ");
        LCD_ShowString(0, 1, "                ");
        DelayMS(2000);
    } else {
        LCD_ShowString(0, 0, "PASSWORDS NOT    ");
        LCD_ShowString(0, 1, "MATCH! TRY AGAIN ");
        AlarmMusic();
        DelayMS(2000);
    }
    
    SettingMode = 0;
    ResetSystem();
    LCD_ShowString(0, 0, "ENTER PASSWORD:  ");
}
void ErrorHandler() {
    ErrorCount++;
    if(ErrorCount >= 3) {
        LockFlag = 1;
        LCD_ShowString(0, 0, "SYSTEM LOCKED!   ");
        LCD_ShowString(0, 1, "PRESS A TO RESET ");
        AlarmMusic();
    } else {
        LCD_ShowString(0, 0, "WRONG PASSWORD!  ");
        LCD_ShowString(0, 1, "TRY AGAIN...     ");
        AlarmMusic();
        DelayMS(1000);
        ResetSystem();
        LCD_ShowString(0, 0, "ENTER PASSWORD:  ");
    }
}
void main() {
    unsigned char key;
    LCD_Init();
    InitTimer0();
    Buzzer = 0;
    Lock_Relay = 0;
    P0 = DIG_CODE[10];
    LCD_ShowString(0, 0, "ENTER PASSWORD:  ");
    LCD_ShowPassword();
    
    while(1) {
        key = KeyScan();
        
        if(key != 16) {
            if(!LockFlag) { 
                if(key < 10) {
                    if(InputCount < 4) {
                        InputPassword[InputCount] = key;
                        InputCount++;
                        DisplayDigit();
                        LCD_ShowPassword();
                    }
                }
                else if(key == 11) { 
                    if(InputCount > 0) {
                        InputCount--;
                        InputPassword[InputCount] = 10;
                        DisplayDigit();
                        LCD_ShowPassword();
                    }
                }
                else if(key == 15) {
                    if(InputCount == 4) {
                        if(CheckPassword()) {
                            LCD_ShowString(0, 0, " VERIFYING...    ");
                            DelayMS(1000);
                            Unlock();
                            ErrorCount = 0;
                            ResetSystem();
                            LCD_ShowString(0, 0, "ENTER PASSWORD:  ");
                        } else {
                            ErrorHandler();
                        }
                    }
                }
                else if(key == 10) {
                    if(SettingMode == 0) {
                        SetNewPassword();
                    }
                }
            } else {
                if(key == 10) {
                    LockFlag = 0;
                    ErrorCount = 0;
                    ResetSystem();
                    LCD_ShowString(0, 0, "SYSTEM RESET OK! ");
                    LCD_ShowString(0, 1, "                ");
                    DelayMS(2000);
                    LCD_ShowString(0, 0, "ENTER PASSWORD:  ");
                }
            }
            DelayMS(200);
        }
        DisplayDigit();
    }
}